﻿namespace P02_FootballBetting;

public class Startup
{
    public static void Main(string[] args)
    {

    }
}