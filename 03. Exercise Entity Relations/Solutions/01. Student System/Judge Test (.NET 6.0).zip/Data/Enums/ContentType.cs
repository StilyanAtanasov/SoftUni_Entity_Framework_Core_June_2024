﻿namespace P01_StudentSystem.Data.Enums;

public enum ContentType
{
    Application,
    Pdf,
    Zip
}