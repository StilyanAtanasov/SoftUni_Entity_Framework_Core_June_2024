﻿namespace ProductShop.DTOs.Export;

public class ProductDto
{
    public string Name { get; set; } = null!;

    public decimal Price { get; set; }
}