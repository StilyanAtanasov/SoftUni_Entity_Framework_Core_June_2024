﻿namespace Invoices.Data.Models.Enums;

public enum CategoryType
{
    // ReSharper disable once InconsistentNaming
    ADR,
    Filters,
    Lights,
    Others,
    Tyres
}