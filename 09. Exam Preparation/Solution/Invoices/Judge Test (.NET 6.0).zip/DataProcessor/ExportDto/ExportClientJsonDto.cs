﻿namespace Invoices.DataProcessor.ExportDto;

public class ExportClientJsonDto
{
    public string Name { get; set; } = null!;

    public string NumberVat { get; set; } = null!;
}